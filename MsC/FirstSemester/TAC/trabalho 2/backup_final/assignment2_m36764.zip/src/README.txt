Os commandos disponiveis no makefile são os seguintes:
	run-X (X é um numero de 1 a 6 - faz print do codigo mips na consola)
	save-X (X é um numero de 1 a 6 - faz print do codigo mips para um ficheiro na pasta "results")
	save-all (corre todos os exemplos e faz print de todos para varios ficheiros na pasta "results")