import java.io.*;
import java.util.*;

public class Process{
	int pid; // n� do processo
	int inst[]; // array de instru��es do processo
	int tamanho; //quantidade de instru��es
	boolean abriu; // boleano que diz se ficheiro existe ou n�o
	int paginas; // n�mero de p�ginas necess�rias para execu��o do processo



	//cria��o do Processo com uma string que � o nome do ficheiro
	//e um pid que o n�mero do processo, sendo cada processo : pid = pid do processo anterior + 1
	public Process(String s, int pid){
		this.pid = pid;
		tamanho = 0;
		abriu = false;

		//tenta-se abrir ficheiro com instru��es
		try (BufferedReader br = new BufferedReader(new FileReader("src/" + s +".txt")))
		{
			//se conseguiu abrir, ficheiro � v�lido 
			abriu = true;

			//l�-se tudo do ficheiro para saber quantidade de instru��es
			String sCurrentLine;
			if((sCurrentLine = br.readLine()) != null) {
				tamanho += (sCurrentLine.length()+1)/2;
				
			}

		//caso nome de ficheiro n�o seja v�lido
		} catch (IOException e) {
			System.out.println("\nFICHEIRO N�O ENCOTRADO/INV�LIDO\n");
		}

		//se ficheiro v�lido, volta a abrir
		if(abriu){
			try(Scanner scanner = new Scanner(new File("src/" + s +".txt"))){

				//� criado array conforme a quantidade das instru��es
				//e � lido do ficheiro as instru��es para o dito array
				inst = new int [tamanho];
				int i = 0;
				while(scanner.hasNextInt()){
					inst[i++] = scanner.nextInt();
				}
			}
			catch(IOException e) {}
		}

	}


	//c�lculo do n�mero de p�ginas necess�rias para o processo	
	public int numPaginas() {
		int k = tamanho/10;
		int result = k;
		if (tamanho%10 > 0)
			result++;

		return result;
	}
}