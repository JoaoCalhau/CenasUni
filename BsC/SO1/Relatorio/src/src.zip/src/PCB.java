public class PCB{
		int pid; // nº do process
		int n_pos; //posição do array de instruções do processo, da instrução a ser realizada

		int stage; // estágio onde processo se encontra : new, ready, run, block, exit 
				  // útilizado nos prints


		//criação de um PCB dado um pid de um processo 
		public PCB(int pid){
			this.pid = pid;
			this.n_pos = 0;
			this.stage = 1;
		}
		
		//operação go to begin, faz com que o processo volte
		//à primeira instrução da lista de instruções
		public void gotoBegin() {
			this.n_pos = 0;
		}
		
		//vai para a próxima instrução do processo
		//da lista de instruções do processo
		public void nextInst() {
			this.n_pos++;
		}
		
		//altera a stage dum processo
		//utilizado quando se move um processo de um estado para outro
		public void setStage(int s) {
			this.stage = s;
		}
		

		//toString para registar no ficheiro scheduler.out
		//o estado atual dos processos
		public String toString() {
			if (this.stage == 1)
				return " new ";
			else if (this.stage == 2)
				return "ready";
			else if (this.stage == 3)
				return "block";
			else if (this.stage == 4)
				return " run ";
			else
				return "exit ";
		}
	}