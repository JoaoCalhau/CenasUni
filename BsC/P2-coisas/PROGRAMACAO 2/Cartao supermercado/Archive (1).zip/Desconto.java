public class Desconto{
  float valor;
  My_Data data;
  My_Data data_valor;
  
  public Desconto(float v){
    valor=v;
    data=new My_Data();
    data_valor=data.diaSeguinte();
  }
  
  public String toString(){
    return valor+"� em "+ data + " tem efeito em "+ data_valor;}
}