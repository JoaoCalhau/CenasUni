//Implementar Listas
//Ficheiro LinkedList.c e LinkedList.h