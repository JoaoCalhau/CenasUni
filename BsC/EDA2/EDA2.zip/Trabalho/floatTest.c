#include <stdio.h>

int main() {
	float cenas;

	cenas = 10.02132;

	printf("%0.2f", cenas);

	return 0;
}