#include <stdio.h>

int main() {
	printf("Ola mundo.\n");
	return 0;
}

