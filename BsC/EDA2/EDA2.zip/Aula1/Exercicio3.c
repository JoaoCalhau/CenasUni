#include <stdio.h>

int main() {
	int i;

	for(i = 1; i<20; i++) {
		printf("%d ",i);
	}

	printf("%d",20);

	return 0;
}

