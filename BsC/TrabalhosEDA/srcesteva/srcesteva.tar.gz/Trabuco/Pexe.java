package Trabuco;

public class Pexe extends Animais {
	Pexe() {
		super(2);
	}
	int getType() {
		return type;
	}
}