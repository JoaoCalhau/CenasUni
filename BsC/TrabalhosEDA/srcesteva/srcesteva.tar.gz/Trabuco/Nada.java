package Trabuco;

public class Nada extends Animais {
	Nada() {
		super(0);
	}
	int getType() {
		return type;
	}
}