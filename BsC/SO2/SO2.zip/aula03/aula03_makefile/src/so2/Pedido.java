package so2;

public abstract class Pedido implements java.io.Serializable {
    
}
