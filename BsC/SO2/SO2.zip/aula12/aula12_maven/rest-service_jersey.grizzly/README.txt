Instala MAVEN e corre com o mvn compile
e depois mvn exec:java