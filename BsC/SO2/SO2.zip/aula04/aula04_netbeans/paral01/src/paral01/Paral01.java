package paral01;

/**
 *
 * @author jsaias
 */
public class Paral01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
