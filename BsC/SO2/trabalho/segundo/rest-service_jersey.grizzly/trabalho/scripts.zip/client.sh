cp web/webTrabalho.war $CATALINA_HOME/webapps
bash $CATALINA_HOME/bin/startup.sh