Modo de uso do ficheiro Client.sh e Server.sh:

bash Server.sh $RegPort $DB_HOST $DB_NAME $DB_USER $DB_PW

e

bash Client.sh $ServIP $RegPort

