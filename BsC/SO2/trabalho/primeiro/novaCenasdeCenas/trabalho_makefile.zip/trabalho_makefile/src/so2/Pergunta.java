package so2;

import java.io.Serializable;
import java.util.ArrayList;

public class Pergunta implements Serializable {
    
    String questao;
    ArrayList<Integer> resposta;
    
    
    public Pergunta(String pergunta) {
        this.questao = pergunta;
        resposta = new ArrayList<Integer>();
        
    }
    
    public void Responder(int valor) {
        this.resposta.add(valor);
        
    }
    
    public int LastValue() {
        return resposta.get(resposta.size()-1);
    }
    
    public float Media() {
        float total=0;
        for(int i = 0; i < resposta.size() ;i++ )
            total += (float)resposta.get(i);
        total=total/(float) resposta.size();
        return total;
    }
    
    public String Nome() {
        return questao;
    }
    
    public int quantRespostas() {
        return resposta.size();
    }
    
    
    @Override
    public String toString() {
        return this.questao;
    }
    
}
