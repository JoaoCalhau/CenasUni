package so2;

import java.rmi.RemoteException;
import java.util.Scanner;


public class MenuServer {

    public static void main(String args[]) throws Exception {
        
	int regPort= 1099;

	if (args.length !=1) { 
	    System.out.println("Usage: java so2.rmi.PalavrasServer registryPort");
	    System.exit(1);
	}
	

	try {
	    regPort=Integer.parseInt(args[0]);

	    ListaQuestionariosImpl obj= new ListaQuestionariosImpl();

            java.rmi.registry.LocateRegistry.createRegistry(regPort);            
            
	    java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.getRegistry(regPort);

	    registry.rebind("quest", obj);

	    System.out.println("Bound RMI object in registry");

            System.out.println("servidor pronto");
            
            System.out.println("(Para fechar o servidor, basta escrever 'exit')");
            System.out.println("('exit' este que também serve para guardar os questionarios em memória)");
            
            Scanner sc = new Scanner(System.in);
            
            while(!sc.nextLine().toUpperCase().equals("EXIT"))
                sc.next();
            
            obj.writeQuest();
            
            System.exit(0);
	} 
	catch (NumberFormatException | RemoteException e) {
	    System.err.println("Oops! Something went wrong!");
	}
    }
    
}
