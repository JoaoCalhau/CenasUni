public class TestClass {
	public static void main(String[] args) {
		
		Euler solved = new Euler();
		System.out.println("Problema 1: "+solved.Problem1());
		System.out.println("Problema 2: "+solved.Problem2());
		System.out.println("Problema 3: "+solved.Problem3());
		System.out.println("Problema 4: "+solved.Problem4());
		System.out.println("Problema 5: "+solved.Problem5());
		System.out.println("Problema 6: "+solved.Problem6(100));
		System.out.println("Problema 7: "+solved.Problem7());
		System.out.println("Problema 8: "+solved.Problem8());
		System.out.println("Problema 9: "+solved.Problem9());
		System.out.println("Problema 10: "+solved.Problem10());
		System.out.println("Problema 11: "+solved.Problem11());
		System.out.println("Problema 12: "+solved.Problem12());
		System.out.println("Problema 13: "+solved.Problem13());
		System.out.println("Problema 14: "+solved.Problem14());
		System.out.println("Problema 15: "+solved.Problem15());
		System.out.println("Problema 16: "+solved.Problem16());
		System.out.println("Problema 18: "+solved.Problem18());
		System.out.println("Problema 20: "+solved.Problem20());
		System.out.println("Problema 21: "+solved.Problem21());
		System.out.println("Problema 25: "+solved.Problem25());
		System.out.println("Problema 28: "+solved.Problem28());
		System.out.println("Problema 29: "+solved.Problem29());
		System.out.println("Problema 30: "+solved.Problem30());
		System.out.println("Problema 48: "+solved.Problem48());
		System.out.println("Problema 67: "+solved.Problem67());
	}
}