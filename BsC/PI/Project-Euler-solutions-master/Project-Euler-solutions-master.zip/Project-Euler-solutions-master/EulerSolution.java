public interface EulerSolution {
	
	public String run();
	
}
