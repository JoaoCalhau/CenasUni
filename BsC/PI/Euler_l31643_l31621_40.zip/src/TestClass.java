public class TestClass {
	public static void main(String[] args) {
		
		Euler solved = new Euler();
		System.out.println("Problema 1: "+solved.Problem1());
		System.out.println("Problema 2: "+solved.Problem2());
		System.out.println("Problema 3: "+solved.Problem3());
		System.out.println("Problema 4: "+solved.Problem4());
		System.out.println("Problema 5: "+solved.Problem5());
		System.out.println("Problema 6: "+solved.Problem6(100));
		System.out.println("Problema 7: "+solved.Problem7());
		System.out.println("Problema 8: "+solved.Problem8());
		System.out.println("Problema 9: "+solved.Problem9());
		System.out.println("Problema 10: "+solved.Problem10());
		System.out.println("Problema 11: "+solved.Problem11());
		System.out.println("Problema 12: "+solved.Problem12());
		System.out.println("Problema 13: "+solved.Problem13());
		System.out.println("Problema 16: "+solved.Problem16());
		System.out.println("Problema 20: "+solved.Problem20());
	}
}