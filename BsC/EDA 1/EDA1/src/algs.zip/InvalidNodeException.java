@SuppressWarnings("serial")
public class InvalidNodeException extends Exception {
	public InvalidNodeException() {}
	public InvalidNodeException(String message) {
		super(message);
	}
}
