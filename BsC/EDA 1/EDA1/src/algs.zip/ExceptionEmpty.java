@SuppressWarnings("serial")
public class ExceptionEmpty extends Exception {
	public ExceptionEmpty() {}
	public ExceptionEmpty(String message) {
		super(message);
	}
}

//l31621 - Jo�o Calhau
//l31643 - Ricardo Benedito