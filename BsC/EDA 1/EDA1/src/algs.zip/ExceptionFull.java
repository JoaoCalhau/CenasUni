@SuppressWarnings("serial")
public class ExceptionFull extends Exception {
	public ExceptionFull() {}
	public ExceptionFull(String message) {
		super(message);
	}
}

//l31621 - Jo�o Calhau
//l31643 - Ricardo Benedito