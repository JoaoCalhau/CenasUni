estado_inicial([bracoEsq([]), bracoDir([]),
				chao(a),chao(b), 
				sobre(d,a), sobre(c,b), 
				livre(d), livre(c)]).



estado_final([bracoEsq([]), bracoDir([]),
				chao(d),sobre(b,d), 
				sobre(c,d), sobre(a,b), sobre(a,c),
				livre(a)]).




accao(desempilharPeqDirSobrePequeno(C), 
	[bracoDir([]), livre(C),sobre(C,B)], 
	[bracoDir(C), livre(B)], 
	[sobre(C,B), livre(C),bracoDir([])])
	:- member(C,[b,c]), member(B,[b,c]), C\=B.

accao(desempilharPeqEsqSobrePequeno(C), 
	[bracoEsq([]), livre(C),sobre(C,B)], 
	[bracoEsq(C), livre(C)], 
	[sobre(C,B), livre(C), bracoEsq([])])
	:- member(C,[b,c]), member(B,[b,c]), C\=B.


accao(desempilharPeqDirSobreChao(B), 
	[bracoDir([]), livre(B), chao(B)], 
	[bracoDir(B)], 
	[chao(B), bracoDir([]),livre(B)])
	:- member(B,[b,c]).

accao(desempilharPeqEsqSobreChao(B), 
	[bracoEsq([]), livre(B), chao(B)], 
	[bracoEsq(B)], 
	[chao(B), bracoEsq([]),livre(B)])
	:- member(B,[b,c]).





accao(empilha2PeqMaoPaGrande(B,C,D), 
	[bracoEsq(C), bracoDir(B), livre(D)], 
	[livre(B), livre(C), sobre(B,D), sobre(C,D), bracoEsq([]), bracoDir([])], 
	[bracoEsq(C), bracoDir(B), livre(D)])
	:- member(D,[a,d]),member(C,[b,c]), D\=C, member(B,[b,c]), C\=B, D\=B.






/* DESEMPILHAR grande em cima de grande para mesa */

accao(empilhaGrandDeGrandParaMesa(D), 
	[livre(D),sobre(D,A)], 
	[livre(A), chao(D)], 
	[sobre(D,A)])
	:- member(D,[a,d]), member(A,[a,d]), A\=D.





/* Empilhar 1 grande em cima de 2 pequenos  */

accao(empilhar1Grand2Peq(A,B,C),
	[livre(B), livre(C), sobre(A,D)], 
	[livre(A), sobre(A,B), sobre(A,C), livre(D)], 
	[livre(B), livre(C), sobre(A,D)])
	:- member(A,[a,d]), member(B,[b,c]),A\=B, member(C,[b,c]), B\=C, A\=C, member(D,[a,d]), D\=A, D\=B, D\=C.


accao(empilhar1Grand2Peq(A,B,C),
	[livre(B), livre(C), chao(A)], 
	[livre(A), sobre(A,B), sobre(A,C)], 
	[livre(B), livre(C), chao(A)])
	:- member(A,[a,d]), member(B,[b,c]),A\=B, member(C,[b,c]), B\=C, A\=C.





