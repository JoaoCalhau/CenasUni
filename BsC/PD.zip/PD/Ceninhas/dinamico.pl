:- dynamic
	asserta/1,
	assertz/2,
	retract/1,
	retractall/1,
	abolish/1.
