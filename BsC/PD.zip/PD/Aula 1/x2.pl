num(z).
num(s(x)) :-num(x).

mais1(X, s(X)).